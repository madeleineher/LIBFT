/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/26 15:44:11 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/26 19:56:57 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

char    *ft_strmapi(char const *s, char (*f) (unsigned int, char));

char	*ft_fake(unsigned int, char c)
{
	return (*c);
}

int		main(void)
{
	char *ptr = "hello";

	ft_strmapi(ptr, ft_fake);
	return (0);
}
