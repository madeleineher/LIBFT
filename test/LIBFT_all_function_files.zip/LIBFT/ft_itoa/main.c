/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/30 12:04:25 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/30 17:09:04 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_itoa(int n);

int		main(int ac, char **av)
{
	char *str;

	ft_itoa(0);

	if (ac == 2)
	{
		str = ft_itoa(atoi(av[1]));
		write(1, str, ft_strlen(str));
	}
	return (0);
}
