/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/17 20:35:10 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 10:20:33 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

void	ft_bzero(void *s, size_t n);

#include <strings.h>
#include <stdio.h>

int	main(void)
{
	char string[30] = "coucou";
	char strinj[30] = "coucou";
	printf("orig -->%s\n", string);
	printf("orig -->%s\n", strinj);
	bzero(string, 9);
	ft_bzero(strinj, 9);
	printf("new --> %s\n", string);
	printf("new --> %s\n", strinj);
	return (0);
}
