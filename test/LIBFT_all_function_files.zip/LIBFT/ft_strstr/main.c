/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/16 16:42:01 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 11:12:28 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

char    *ft_strstr(const char *haystack, const char *needle);

int main(void)
{
	const char *largestring = "hello i am a grey computer";
	const char *smallstring = "com";
	const char *ptr;
	const char *ptr2;

	ptr = strstr(largestring, smallstring);
	ptr2 = ft_strstr(largestring, smallstring);

	printf("REAL --> %s\n", ptr);
	printf("MEEE --> %s\n", ptr2);

}
