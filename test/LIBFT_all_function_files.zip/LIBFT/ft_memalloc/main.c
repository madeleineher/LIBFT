/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 18:15:20 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/29 14:55:35 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void	*ft_memalloc(size_t size);

int		main(void)
{
	char *ptr;

	ptr = (char*)ft_memalloc(9);
	printf("ptr = %p\n", ptr);
	return (0);
}
