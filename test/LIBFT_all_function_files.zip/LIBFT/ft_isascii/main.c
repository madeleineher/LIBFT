/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/13 12:03:44 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/13 12:04:20 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

int main(void)
{
	int string0 = 128;
	int string1 = -48;
	int string2 = 49;
	int string3 = 50;
	int string4 = 51;
	int string5 = 52;
	int string6 = 53;
	int string7 = 54;
	int string8 = 58;
	int string9 = 57;

	printf("0. %d\n", ft_isascii(string0));
	printf("1. %d\n", ft_isascii(string1));
	printf("2. %d\n", ft_isascii(string2));
	printf("3. %d\n", ft_isascii(string3));
	printf("4. %d\n", ft_isascii(string4));
	printf("5. %d\n", ft_isascii(string5));
	printf("6. %d\n", ft_isascii(string6));
	printf("7. %d\n", ft_isascii(string7));
	printf("8. %d\n", ft_isascii(string8));
	printf("9. %d\n", ft_isascii(string9));

	printf("IS DIGIT ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	printf("0. %d\n", isascii(string0));
	printf("1. %d\n", isascii(string1));
	printf("2. %d\n", isascii(string2));
	printf("3. %d\n", isascii(string3));
	printf("4. %d\n", isascii(string4));
	printf("5. %d\n", isascii(string5));
	printf("6. %d\n", isascii(string6));
	printf("7. %d\n", isascii(string7));
	printf("8. %d\n", isascii(string8));
	printf("9. %d\n", isascii(string9));

	return (0);
}
