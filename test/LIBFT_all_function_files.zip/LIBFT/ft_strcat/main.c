/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/20 12:06:14 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/29 20:22:53 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>
char	*ft_strcat(char *restrict s1, const char *restrict s2);

int		main(void)
{
	char	str1[50] = "the cake is a lie !\0I'm hidden lol\r\n";
	char	*str2 = NULL;

//	printf("ORIG =====> %s\n", strcat(str2, str1));
	printf("MEEE -----> %s\n", ft_strcat(str1, str2));

	return(0);
}
