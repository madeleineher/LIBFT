/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/18 11:51:17 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 10:33:40 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

void	*ft_memset(void *b, int c, size_t len);

#include <stdio.h>

int	main(void)
{
	char str[50] = "this is a memset test.";
	char stt[50] = "this is a memset test.";

	printf("\nBefore memset(): %s\n", str); 
	printf("Before ft_memset(): %s\n", stt);

    memset(str + 13, '.', 8*sizeof(char));
	ft_memset(stt + 13, '.', 8*sizeof(char));

    printf("After memset ------> %s\n", str);
	printf("After ft_memset ---> %s\n", stt);

    return 0;
}
