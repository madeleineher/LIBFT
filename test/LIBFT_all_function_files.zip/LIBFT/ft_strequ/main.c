/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/22 19:22:38 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/25 15:20:36 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

int	ft_strequ(char const *s1, char const *s2);

int	main(void)
{
	char *s1 = "hello world";
	char *s2 = "hello world";

	printf("%d\n", ft_strequ(s1, s2));
	
	return (0);
}
