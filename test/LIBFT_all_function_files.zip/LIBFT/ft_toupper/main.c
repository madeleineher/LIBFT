/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/13 14:23:57 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/13 14:24:19 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <ctype.h>
#include <stdio.h>

int main(void)
{
	int string0 = 1;
	int string1 = 11;
	int string2 = 22;
	int string3 = 9;
	int string4 = 99;
	int string5 = 64;
	int string6 = 60;
	int string7 = 78;
	int string8 = 79;
	int string9 = 99;

	printf("0. %d\n", ft_toupper(string0));
	printf("1. %d\n", ft_toupper(string1));
	printf("2. %d\n", ft_toupper(string2));
	printf("3. %d\n", ft_toupper(string3));
	printf("4. %d\n", ft_toupper(string4));
	printf("5. %d\n", ft_toupper(string5));
	printf("6. %d\n", ft_toupper(string6));
	printf("7. %d\n", ft_toupper(string7));
	printf("8. %d\n", ft_toupper(string8));
	printf("9. %d\n", ft_toupper(string9));

	printf("TO UPPER  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	printf("0. %d\n", toupper(string0));
	printf("1. %d\n", toupper(string1));
	printf("2. %d\n", toupper(string2));
	printf("3. %d\n", toupper(string3));
	printf("4. %d\n", toupper(string4));
	printf("5. %d\n", toupper(string5));
	printf("6. %d\n", toupper(string6));
	printf("7. %d\n", toupper(string7));
	printf("8. %d\n", toupper(string8));
	printf("9. %d\n", toupper(string9));

	return (0);
}
