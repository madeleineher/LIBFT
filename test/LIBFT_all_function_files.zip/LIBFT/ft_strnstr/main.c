/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/19 18:54:55 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/29 22:13:41 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char    *ft_strnstr(const char *haystack, const char *needle, size_t len);

#include <string.h>
#include <stdio.h>

int     main(void)
{
	char *haystack = "Hello les genw";
	char *needle = "les";

	char *ptr;
	char *ptr2;

	ptr = strnstr(haystack, needle, 1);
	printf("REAL ----> %s\n", ptr);
	ptr = strnstr(haystack, needle, 0);
	printf("REAL ----> %s\n", ptr);
	ptr = strnstr(haystack, needle, 4);
	printf("REAL ----> %s\n", ptr);
	ptr = strnstr(haystack, needle, 8);
	printf("REAL ----> %s\n", ptr);
	ptr = strnstr(haystack, needle, 6);
	printf("REAL ----> %s\n", ptr);
	ptr = strnstr(haystack, needle, 7);
	printf("REAL ----> %s\n", ptr);

	printf("========================================================\n");
	
	ptr2 = ft_strnstr(haystack, needle, 1);
	printf("MEEE ----> %s\n", ptr2);
	ptr2 = ft_strnstr(haystack, needle, 0);
	printf("MEEE ----> %s\n", ptr2);
	ptr2 = ft_strnstr(haystack, needle, 4);
	printf("MEEE ----> %s\n", ptr2);
	ptr2 = ft_strnstr(haystack, needle, 5);
	printf("MEEE ----> %s\n", ptr2);
	ptr2 = ft_strnstr(haystack, needle, 6);
	printf("MEEE ----> %s\n", ptr2);
	ptr2 = ft_strnstr(haystack, needle, 7);
	printf("MEEE ----> %s\n", ptr2);
	
	return (0);
}
