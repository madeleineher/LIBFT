/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/20 11:41:18 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 13:45:11 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

void *ft_memchr(const void *s, int c, size_t n);

int	main(void)
{
	char *test = "hello";
	
	printf("----> %s\n", (char*)memchr(test, 'z', 7));
	printf("++++> %s\n", (char*)ft_memchr(test, 'z', 7));
	return (0);
}
