/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/13 14:41:10 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/13 14:41:27 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int main(void)
{
	int string0 = 65;
	int string1 = 70;
	int string2 = 80;
	int string3 = 85;
	int string4 = 85;
	int string5 = 64;
	int string6 = 60;
	int string7 = 78;
	int string8 = 79;
	int string9 = 99;

	printf("0. %d\n", ft_tolower(string0));
	printf("1. %d\n", ft_tolower(string1));
	printf("2. %d\n", ft_tolower(string2));
	printf("3. %d\n", ft_tolower(string3));
	printf("4. %d\n", ft_tolower(string4));
	printf("5. %d\n", ft_tolower(string5));
	printf("6. %d\n", ft_tolower(string6));
	printf("7. %d\n", ft_tolower(string7));
	printf("8. %d\n", ft_tolower(string8));
	printf("9. %d\n", ft_tolower(string9));

	printf("TO UPPER  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	printf("0. %d\n", tolower(string0));
	printf("1. %d\n", tolower(string1));
	printf("2. %d\n", tolower(string2));
	printf("3. %d\n", tolower(string3));
	printf("4. %d\n", tolower(string4));
	printf("5. %d\n", tolower(string5));
	printf("6. %d\n", tolower(string6));
	printf("7. %d\n", tolower(string7));
	printf("8. %d\n", tolower(string8));
	printf("9. %d\n", tolower(string9));

	return (0);
}
