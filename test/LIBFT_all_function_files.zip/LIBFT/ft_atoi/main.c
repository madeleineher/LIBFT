/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/19 17:20:35 by mhernand          #+#    #+#             */
/*   Updated: 2018/12/02 12:35:33 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>
#include <string.h>

int	ft_atoi(const char *str);

int     main(void)
{

	printf("not MEE --> %d\n", atoi("\n\v\t\r\f -123"));
	printf("not MEE --> %d\n", atoi("12-3"));
	printf("not MEE --> %d\n", atoi("-+123"));
	printf("not MEE --> %d\n", atoi("a123"));
	printf("not MEE --> %d\n", atoi("123a"));
	printf("not MEE --> %d\n", atoi("123"));
	printf("not MEE --> %d\n", atoi("-123"));
	printf("not MEE --> %d\n", atoi("+123"));
	printf("not MEE --> %d\n", atoi(" - 123"));
	printf("not MEE --> %d\n", atoi("\t -123"));
	printf("not MEE --> %d\n", atoi(" - 123"));
	printf("not MEE --> %d\n", atoi("-2147483648"));
	printf("not MEE --> %d\n", atoi("2147483647"));

	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");

	printf("meeeeee --> %d\n", ft_atoi("\n\v\t\r\f -123"));
	printf("meeeeee --> %d\n", ft_atoi("12-3"));
	printf("meeeeee --> %d\n", ft_atoi("-+123"));
	printf("meeeeee --> %d\n", ft_atoi("a123"));
	printf("meeeeee --> %d\n", ft_atoi("123a"));
	printf("meeeeee --> %d\n", ft_atoi("123"));
	printf("meeeeee --> %d\n", ft_atoi("-123"));
	printf("meeeeee --> %d\n", ft_atoi("+123"));
	printf("meeeeee --> %d\n", ft_atoi(" - 123"));
	printf("meeeeee --> %d\n", ft_atoi("\t -123"));
	printf("meeeeee --> %d\n", ft_atoi(" - 123"));
	printf("meeeeee --> %d\n", ft_atoi("-2147483648"));
	printf("meeeeee --> %d\n", ft_atoi("2147483647"));

	return (0);
}
