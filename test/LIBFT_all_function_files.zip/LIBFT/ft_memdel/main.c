/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 18:38:12 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/26 13:49:12 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void	ft_memdel(void **ap);

int		main(void)
{
	char *ptr;
	size_t size;

	size = 10;

	ptr = (char*)malloc(sizeof(ptr) * (size + 1));
	ft_memdel((void**)&ptr);

	return (0);
}
