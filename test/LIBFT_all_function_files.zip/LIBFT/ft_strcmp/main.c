/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/13 15:27:36 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 10:43:09 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int     ft_strcmp(const char *s1, const char *s2);

#include <string.h>

int main(void)
{
	char *str1 = "- 1reogn";
	char *str2 = "-  =";

	printf("yours : %d\n", ft_strcmp(str1, str2));
	printf("strcmps : %d", strcmp(str1, str2));
	return (0);
}
