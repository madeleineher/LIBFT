/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/19 19:53:24 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/19 22:38:24 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

void    *ft_memccpy(void *restrict dst, const void *restrict src, int c, size_t n);

#include <stdio.h>
/*
int	main(void)
{
	char src[30] = "hello world!";
	char dst[30] = "not a hello";
	char *test1;
	int myint = 119;
	unsigned char charly;
	charly = (unsigned char)myint;

	printf("NOOOOOOOOOOOT ME : before memccpy test --> %s\n", src);
	test1 = memccpy(dst, src, charly, 10);
	printf("output : %s\n", test1);
	
	char src2[30] = "hello world!";
	char dst2[30] = "not a hello";
	char *test2;
	int myint2 = 119;
	unsigned char charly2;
	charly2 = (unsigned char)myint2;

	printf("MEEEEEEEEEEEEEEE : before ft_memccpy test --> %s\n", src2);
	test2 = ft_memccpy(dst2, src2, charly2, 10);
	printf("output mee : %s\n", test2);

	return (0);
}*/

int	main(void)
{
	char	src[30] = "ABCDEFGH";
	char	dst[30] = "12345678";
	char	*check = NULL;

	check = ft_memccpy(dst, src, 0, 9);
	printf("%s\n", check);
	return (0);
}

