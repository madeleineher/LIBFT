/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/20 12:00:48 by mhernand          #+#    #+#             */
/*   Updated: 2018/12/05 00:12:13 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <string.h>
#include <stdio.h>

char	*ft_strncat(char *restrict s1, const char *restrict s2, size_t n);

int		main(void)
{
	char	*dest;
	dest[0] = '\0';
	dest[10] = 'a';

	printf("%s\n", strncat(dest, "lorem ipsum", 10));
/*	printf("%s\n", strncat(dest, "Hello ", 2));
	printf("%s\n", strncat(dest, "Hello ", 10));
	printf("%s\n", strncat(dest, "1234\n78", 7));
*/
	printf("--\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n--\n");

	printf("%s\n", ft_strncat(dest, "lorem ipsum", 10));
/*	printf("%s\n", ft_strncat(dest2, "Hello ", 4));
	printf("%s\n", ft_strncat(dest2, "Hello ", 2));
	printf("%s\n", ft_strncat(dest2, "Hello ", 10));
	printf("%s\n", ft_strncat(dest2, "1234\n78", 7));
*/
	return (0);
}
