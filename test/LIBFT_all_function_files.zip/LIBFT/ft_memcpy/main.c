/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/18 14:13:45 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/29 17:45:33 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

void	*ft_memcpy(void *restrict dest, const void *restrict src, size_t n);

int	main(void)
{
	char dest1[50];
	char dest2[50];

	ft_putchar('a');	
	memcpy(NULL, NULL, 30);
	ft_putchar('b');
	ft_memcpy(NULL, NULL, 30);
	ft_putchar('c');

	printf("After memcpy dest ------> %s\n", dest1);
	printf("After ft_memcpy dest ---> %s\n", dest2);

	return(0);

}
