/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/20 11:51:34 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 14:48:13 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

void	*ft_memmove(void *dst, const void *src, size_t len);

int		main(void)
{
	char dest[] = "hello";
	const char src[]  = "people";

	printf("Before memmove dest = %s, src = %s\n", dest, src);
	memmove(dest, src, 5);
	printf("After memmove dest = %s, src = %s\n", dest, src);

	char dest2[] = "hello";
	const char src2[]  = "people";

	printf("Before memmove dest = %s, src = %s\n", dest2, src2);
	ft_memmove(dest2, src2, 5);
	printf("After memmove dest = %s, src = %s\n", dest2, src2);

	return (0);
}
