/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/27 13:09:41 by mhernand          #+#    #+#             */
/*   Updated: 2018/12/02 16:54:14 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char    *ft_strtrim(char const *s);

int		main(void)
{
	char	str[] = "  \t    \t\nBon\t \njour\t\n  \n     ";
	char	str2[] = "";
	char	str3[] = "  \t\t\t   ";

	printf("%s\n", ft_strtrim(str));
	printf("%s\n", ft_strtrim(str2));
	printf("%s\n", ft_strtrim(str3));
	return (0);
}
