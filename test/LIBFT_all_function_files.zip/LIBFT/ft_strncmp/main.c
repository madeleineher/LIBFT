/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/15 15:12:13 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 11:10:04 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int ft_strncmp(const char *str1, const char *str2, size_t n);

int main(void)
{
	const char *str1 = "";
	const char *str2 = " ";
	int n = 3;

	printf("MINE ---> %d\n", ft_strncmp(str1, str2, n));
	printf("ACTUAL -> %d", strncmp(str1, str2, n));
	return(0);
}
