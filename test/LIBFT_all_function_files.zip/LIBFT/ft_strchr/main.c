/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/20 11:53:41 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 16:03:54 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strchr(const char *s, int c);

int		main(void)
{
	const char *silly_string = "i am a stress test";
	char *output;

	output = strchr(silly_string, 'z');
	printf("i am ORIG output --> %s\n", output);

	const char *silly_string2 = "i am a stress test";
	char *output2;

	output2 = ft_strchr(silly_string2, 'z');
	printf("i am YOUR output --> %s\n", output2);

	return (0);
}
