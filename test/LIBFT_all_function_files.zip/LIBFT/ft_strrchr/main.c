/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/20 11:55:43 by mhernand          #+#    #+#             */
/*   Updated: 2018/12/04 23:31:41 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

char	*ft_strrchr(const char *s, int c);

int		main(void)
{
	char *string = "bonjour";

	printf("%s\n", ft_strrchr(string, 'b'));
	printf("%s\n", strrchr(string, 'b'));

	return (0);
}
