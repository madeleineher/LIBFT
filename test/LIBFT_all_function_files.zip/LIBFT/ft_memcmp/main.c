/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/18 17:51:41 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/18 19:22:46 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

int	ft_memcmp(const void *s1, const void *s2, size_t n);

int	main(void)
{
	char string1[20] = "hello world !";
	char string2[20] = "hello world !";
	
	printf("\nreal diff -->  %d\n", memcmp(string1, string2, 13));
	printf("\nmeee diff -->  %d\n\n", ft_memcmp(string1, string2, 13));

	return (0);
}
