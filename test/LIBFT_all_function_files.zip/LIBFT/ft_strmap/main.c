/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/26 14:18:58 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/26 16:13:25 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h>
#include <unistd.h>

char    *ft_strmap(char const *s, char (*f) (char));

char	*ft_fake(char c)
{
	return (*c);
}

int		main(void)
{
	char *ptr = "hello";

	ft_strmap(ptr, ft_fake);
	return (0);
}
