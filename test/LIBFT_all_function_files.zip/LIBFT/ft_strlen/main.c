/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/12 19:58:39 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 11:07:09 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int	ft_strlen(const char *str);

int main(void)
{
	char *string0 = "hello";
	char *string1 = "";
	char *string2 = "abc";
	char *string3 = "o";
	char *string4 = "hellohellohello";
	char *string5 = "_";
	char *string6 = "49832-3tugroij";
	char *string7 = "vlkanevlne";
	char *string8 = "NULL";
	char *string9 = "z";

	printf("%d\n", ft_strlen(string0));
	printf("%d\n", ft_strlen(string1));
	printf("%d\n", ft_strlen(string2));
	printf("%d\n", ft_strlen(string3));
	printf("%d\n", ft_strlen(string4));
	printf("%d\n", ft_strlen(string5));
	printf("%d\n", ft_strlen(string6));
	printf("%d\n", ft_strlen(string7));
	printf("%d\n", ft_strlen(string8));
	printf("%d\n", ft_strlen(string9));

	printf("-----------------------------------------------------\n");

	printf("%lu\n", strlen(string0));
	printf("%lu\n", strlen(string1));
	printf("%lu\n", strlen(string2));
	printf("%lu\n", strlen(string3));
	printf("%lu\n", strlen(string4));
	printf("%lu\n", strlen(string5));
	printf("%lu\n", strlen(string6));
	printf("%lu\n", strlen(string7));
	printf("%lu\n", strlen(string8));
	printf("%lu\n", strlen(string9));

	return(0);
}
