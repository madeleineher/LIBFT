/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/17 19:16:41 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/29 16:27:56 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	ft_strncpy(char *dst, const char *src, int len);

#include <stdio.h>
#include <string.h>

int	main(void)
{
	char dst[40];
	char dst2[40];

	strncpy(dst, "hello", 30);
	ft_strncpy(dst2, "hello", 30);
	
	printf("REAAL ----> %s", dst);
	printf("\n");
	printf("MEEEE ----> %s", dst);
	printf("\n");
			
	return(0);
}
