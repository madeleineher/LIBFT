/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/20 10:52:57 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/20 11:03:42 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char    *ft_strdup(const char *s1);

int	main(void)
{
	const char *string = "hello mon ami !";

	printf("real : %s\n", strdup(string));
	printf("test : %s\n", ft_strdup(string));
}
