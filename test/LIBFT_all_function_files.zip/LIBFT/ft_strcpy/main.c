/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/17 18:50:14 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/17 18:58:44 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char *ft_strcpy (char *dest, const char *src);

#include <string.h>
#include <stdio.h>

int main(void)
{
	char source[400];
	char source2[400];

	strcpy(source, "hello dear");
	ft_strcpy(source2, "hello dear");

	printf("REAL -------> %s\n", source);
	printf("MEEE -------> %s\n", source2);

	return (0);
}
