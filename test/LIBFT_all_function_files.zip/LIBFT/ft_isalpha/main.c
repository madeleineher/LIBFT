/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/13 11:33:10 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/13 11:33:33 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
	int string0 = 103;  //C
	int string1 = 143;  //c
	int string2 = 128;  // ""
	int string3 = 173;  // {
	int string4 = 177;  // del
	int string5 = 005;  // enq
	int string6 = 100;  // @ ???
	int string7 = 131;  // W
	int string8 = 133;  // [
	int string9 = 072;  // :

	printf("0. %d\n", ft_isalpha(string0));
	printf("1. %d\n", ft_isalpha(string1));
	printf("2. %d\n", ft_isalpha(string2));
	printf("3. %d\n", ft_isalpha(string3));
	printf("4. %d\n", ft_isalpha(string4));
	printf("5. %d\n", ft_isalpha(string5));
	printf("6. %d\n", ft_isalpha(string6));
	printf("7. %d\n", ft_isalpha(string7));
	printf("8. %d\n", ft_isalpha(string8));
	printf("9. %d\n", ft_isalpha(string9));

	printf("IS ALPHA ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	printf("0. %d\n", isalpha(string0));
	printf("1. %d\n", isalpha(string1));
	printf("2. %d\n", isalpha(string2));
	printf("3. %d\n", isalpha(string3));
	printf("4. %d\n", isalpha(string4));
	printf("5. %d\n", isalpha(string5));
	printf("6. %d\n", isalpha(string6));
	printf("7. %d\n", isalpha(string7));
	printf("8. %d\n", isalpha(string8));
	printf("9. %d\n", isalpha(string9));

	return (0);
}
