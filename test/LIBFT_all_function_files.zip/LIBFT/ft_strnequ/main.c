/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/25 17:06:32 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/25 17:22:42 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_strnequ(char const *s1, char const *s2, size_t n);

#include <stdio.h>

int	main(void)
{
	char *s1 = "hello";
	char *s2 = "hellppo";

	printf("%d", ft_strnequ(s1, s2, 5));
}
