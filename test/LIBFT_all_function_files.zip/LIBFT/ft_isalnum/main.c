/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/13 13:44:21 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/13 13:45:05 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <ctype.h>

int main(void)
{
	int string0 = 48;
	int string1 = 47;
	int string2 = 122;
	int string3 = 123;
	int string4 = 58;
	int string5 = 64;
	int string6 = 60;
	int string7 = 78;
	int string8 = 79;
	int string9 = 99;

	printf("0. %d\n", ft_isalnum(string0));
	printf("1. %d\n", ft_isalnum(string1));
	printf("2. %d\n", ft_isalnum(string2));
	printf("3. %d\n", ft_isalnum(string3));
	printf("4. %d\n", ft_isalnum(string4));
	printf("5. %d\n", ft_isalnum(string5));
	printf("6. %d\n", ft_isalnum(string6));
	printf("7. %d\n", ft_isalnum(string7));
	printf("8. %d\n", ft_isalnum(string8));
	printf("9. %d\n", ft_isalnum(string9));

	printf("IS PRINT  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	printf("0. %d\n", isalnum(string0));
	printf("1. %d\n", isalnum(string1));
	printf("2. %d\n", isalnum(string2));
	printf("3. %d\n", isalnum(string3));
	printf("4. %d\n", isalnum(string4));
	printf("5. %d\n", isalnum(string5));
	printf("6. %d\n", isalnum(string6));
	printf("7. %d\n", isalnum(string7));
	printf("8. %d\n", isalnum(string8));
	printf("9. %d\n", isalnum(string9));

	return (0);
}
