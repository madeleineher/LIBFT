/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/21 18:45:54 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/26 14:16:57 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

void	ft_strdel(char **as);

int		main(void)
{
	char *ptr;
	size_t size;

	size = 11;

	ptr = (char*)malloc(sizeof(ptr) * (size + 1));
	ft_strdel(&ptr);
	return (0);
}
