/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhernand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/13 12:35:19 by mhernand          #+#    #+#             */
/*   Updated: 2018/11/13 12:35:56 by mhernand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>
#include <stdio.h>

int main(void)
{
	int string0 = 177;
	int string1 = 180;
	int string2 = 0;
	int string3 = 35;
	int string4 = 40;
	int string5 = 39;
	int string6 = 53;
	int string7 = 78;
	int string8 = 79;
	int string9 = 99;

	printf("0. %d\n", ft_isprint(string0));
	printf("1. %d\n", ft_isprint(string1));
	printf("2. %d\n", ft_isprint(string2));
	printf("3. %d\n", ft_isprint(string3));
	printf("4. %d\n", ft_isprint(string4));
	printf("5. %d\n", ft_isprint(string5));
	printf("6. %d\n", ft_isprint(string6));
	printf("7. %d\n", ft_isprint(string7));
	printf("8. %d\n", ft_isprint(string8));
	printf("9. %d\n", ft_isprint(string9));

	printf("IS PRINT  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

	printf("0. %d\n", isprint(string0));
	printf("1. %d\n", isprint(string1));
	printf("2. %d\n", isprint(string2));
	printf("3. %d\n", isprint(string3));
	printf("4. %d\n", isprint(string4));
	printf("5. %d\n", isprint(string5));
	printf("6. %d\n", isprint(string6));
	printf("7. %d\n", isprint(string7));
	printf("8. %d\n", isprint(string8));
	printf("9. %d\n", isprint(string9));

	return (0);
}
